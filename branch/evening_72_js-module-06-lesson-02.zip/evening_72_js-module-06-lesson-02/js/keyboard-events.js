'use strict';
/*
  3. Події клавіатури: keydown, keyup
*/

// const outputEl = document.querySelector('.js-output');

// // document.addEventListener('keyup', (event) => {
// //   outputEl.insertAdjacentHTML(
// //     'beforeend',
// //     `code: ${event.code} <br> key: ${event.key} <br> <hr>`
// //   );
// // });

// // document.addEventListener('keypress', (e) => {
// //   console.log(e);
// // });

// document.addEventListener('keydown', (e) => {
//   e.preventDefault();

//   if (e.ctrlKey && e.code === 'KeyS') {
//     alert('Cntr + S combination');
//   }
// });
