# Занятие 14:

- Сhatty events
- Throttle и debounce событий c библиотекой Lodash
- Lazy-loading images: нативная и с библиотекой lazysizes
- Использование библиотек через CDN
