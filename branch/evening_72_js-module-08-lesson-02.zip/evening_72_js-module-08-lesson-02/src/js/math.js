export const add = (a, b) => {
  return a + b;
};

export const sub = (a, b) => {
  return a - b;
};

export const division = (a, b) => {
  return a / b;
};

export const multi = (a, b) => {
  return a * b;
};

export default { add, sub, division, multi };

console.log(44244);
