// import { add, division as func } from './math';
import methodsObj from './math';

// console.log(add(5, 5));
// console.log(func(25, 5));

// console.log(methodsObj);

import * as module from './math';

// console.log(module)

// const user = {
//   name: 'Andrii',
//   age: 5,
//   showName() {
//     console.log(this.name);
//   },
//   city: undefined,
// };

// const userJSON = JSON.stringify(user);

// // console.log(typeof userJSON);

// const userJS = JSON.parse(userJSON);

// console.log(userJSON);
// console.log(userJS);
// console.log(1);

// const strValue = '"True or False"';

// let string;

// try {
//   string = JSON.parse(strValue);
// } catch (err) {
//   console.warn(err);
// }

// console.log(2);

// const user = {
//   name: 'Andrii',
//   age: 5,
// };

// localStorage.setItem('user', JSON.stringify(user));

// console.log(JSON.parse(localStorage.getItem('user')));

// // localStorage.clear();

// localStorage.removeItem('user');
