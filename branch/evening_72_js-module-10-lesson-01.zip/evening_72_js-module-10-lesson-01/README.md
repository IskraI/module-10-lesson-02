# Занятие 19:

- Взаимодействие с публичным REST API
- Вкладка Network
- Fetch API
- HTTP-методы, заголовки, MIME-типы, статус-коды ответа
- Параметры строки запроса и класс URLSearchParams
- Кросс-доменные запросы (CORS)
- [клиент-серверная архитектура](https://habr.com/ru/post/495698/)
- [сервис с разлисными api](https://rapidapi.com/hub)
- [api с картинками](https://unsplash.com/)
