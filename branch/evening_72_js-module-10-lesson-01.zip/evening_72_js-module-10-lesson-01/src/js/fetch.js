'use strict';

// https://habr.com/ru/post/495698/

// https://jsonplaceholder.typicode.com/

// fetch('https://jsonplaceholder.typicode.com/users?_limit=5&_sort=username')
//   .then(response => {
//     if (!response.ok) {
//       throw new Error(response.status);
//     }

//     return response.json();
//   })
//   .then(data => {
//     console.log(data);
//   })
//   .catch(err => {
//     console.warn(err);
//   });
