console.log('Hello from index.js');
console.log(10 + 55);

const array = [1, 2, 3, 4];

const array2 = [...array];

const func = (a, b) => a + b;
